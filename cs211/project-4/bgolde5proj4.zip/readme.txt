1. $make proj4

2. $./proj4 or $./proj4 -d for debugging mode

3. $make clean
  -removes object files

4. $make remove
  -removes executable proj4
