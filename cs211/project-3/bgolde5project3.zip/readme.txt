Restaurant Waiting List System

1. $ make waiting_system
2. $ ./waiting_system 
       -or-
   $ ./waiting_system -d (for debugging purposes)
3. make clean (remove object files)
4. make remove (remove executable file)
