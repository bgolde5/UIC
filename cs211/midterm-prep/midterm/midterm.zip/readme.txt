1. compile program by typing $make test
2. run program by typing $./test <filename>
3. remove object files by typing $make clean
4. remove executable by typing &make remove
