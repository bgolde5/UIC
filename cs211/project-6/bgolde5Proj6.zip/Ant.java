public class Ant extends Creature {
    
    public Ant(Habitat habitat) {
        super(habitat);
    }

    public Ant(Habitat habitat, int newM, int newN){
      super(habitat, newM, newN);
    }
}
