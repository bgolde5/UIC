﻿//
// uiTunes music purchase application
//
// Braldey Golden
// U. of Illinois, Chicago
// CS480, Summer2015
// Homework 3
//

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace uiTunes
{
    public partial class purchase_form : Form
    {
        string firstname, lastname, filename, connectionInfo;
        decimal accountBal, price;
        int userid, purchaseItemid;

        public purchase_form()
        {
            InitializeComponent();

            //constuctor
            firstname = login_form.firstname;
            lastname = login_form.lastname;
            userid = login_form.userid;
            connectionInfo = login_form.connectionInfo;
            filename = login_form.filename;
        }

        private void uiTunesToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            login_form loginWindow = new login_form();
            Application.Exit();
        }

        private void logoutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
            login_form loginWindow = new login_form();
            loginWindow.Show();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void purchase_form_Load(object sender, EventArgs e)
        {
            string sql, msg;
            SqlCommand cmd;
            object result;
            SqlConnection db = new SqlConnection(connectionInfo);

            //set username label at top of form
            if (firstname.Length == 0 | lastname.Length == 0)
            {
                //error has occured and names were not fetched
                return;
            }

            username_label.Text = firstname.ToUpper() + " " + lastname.ToUpper();

            db.Open();

            //get user's account balance from database
            sql = String.Format("SELECT AcctBal FROM Users WHERE UserID = '{0}';", userid);

            if (sql == "null")
            {
                //error has occured, account balance has not been fetched properly
                return;
            }

            cmd = new SqlCommand();

            cmd.Connection = db;
            cmd.CommandText = sql;

            result = cmd.ExecuteScalar();

            accountBal = System.Convert.ToDecimal(result);

            if (accountBal <= 0)
                accnt_bal_label.ForeColor = System.Drawing.Color.Red;
            else
                accnt_bal_label.ForeColor = System.Drawing.Color.Green;

            //set account balance label at top of form
            accnt_bal_label.Text = accountBal.ToString("0.00");

            //
            //load songs into songs_listbox
            //
            sql = "SELECT * FROM Songs ORDER BY SongName ASC;";

            cmd.CommandText = sql;
            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            adapter.Fill(ds);

            DataTable dt = ds.Tables["TABLE"];

            foreach (DataRow row in dt.Rows)
            {
                msg = string.Format("{0}", row["SongName"].ToString());
                songs_listbox.Items.Add(msg);
            }

            //
            //load albums into albums_listbox
            //
            sql = "SELECT * FROM Albums ORDER BY AlbumName ASC;";

            cmd.CommandText = sql;
            adapter = new SqlDataAdapter(cmd);
            ds = new DataSet();
            adapter.Fill(ds);

            dt = ds.Tables["TABLE"];

            foreach (DataRow row in dt.Rows)
            {
                msg = string.Format("{0}", row["AlbumName"].ToString());
                albums_listbox.Items.Add(msg);
            }

            db.Close();

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void songs_label_Click(object sender, EventArgs e)
        {

        }

        private void songs_listbox_SelectedIndexChanged(object sender, EventArgs e)
        {
            //clear albums selection while song list box is selected
            albums_listbox.SelectedIndex = -1;

            //hide purchase_label - this label warns the user if they have bought an item previous or their
            //balance is too low
            purchase_label.Visible = false;
            
            //show purchase info labels, purchase button
            if (songs_listbox.SelectedIndex >= 0)
            {
                toggleLabels(true);
                purchase_button.Visible = true;
            }
            else
            {
                toggleLabels(false);
                purchase_button.Visible = false;
            }

            //initialize and open database
            string sql;
            //string firstname, lastname, password;
            SqlCommand cmd;
            object result;
            SqlConnection db = new SqlConnection(connectionInfo);
            db.Open();

            //
            //get artist name from database
            //
            string artistname;
            string songname = songs_listbox.Text;
            sql = String.Format(@"
                SELECT ArtistName FROM Artists
	                INNER JOIN(
	                SELECT ArtistID FROM SongDetails
		                INNER JOIN(
		                SELECT SongID FROM Songs WHERE SongName = '{0}'
		                ) T
		                ON SongDetails.SongID = T.SongID
	                ) T2
	                ON Artists.ArtistID = T2.ArtistID;", songname);

            cmd = new SqlCommand();
            cmd.Connection = db;
            cmd.CommandText = sql;

            result = cmd.ExecuteScalar();
            try
            {
                artistname = result.ToString();
            }
            catch (Exception artistException)
            {
                Console.WriteLine("{0} Exception Caught", artistException);
                artistname = "Unknown";
            }

            //
            //get song id, this is to be used if the user tries to purchase this song
            //
            int songid;
            sql = String.Format(@"
                SELECT SongID FROM Songs WHERE SongName = '{0}';", songname);

            cmd = new SqlCommand();
            cmd.Connection = db;
            cmd.CommandText = sql;

            result = cmd.ExecuteScalar();
            try
            {
                songid = System.Convert.ToInt32(result);
                purchaseItemid = songid; //set purchaseitemid if user decides to buy
            }
            catch (Exception SongID)
            {
                Console.WriteLine("{0} Exception Caught", SongID);
                return; //error has occured
            }

            //
            //get release date from database
            //
            string relDate;
            sql = String.Format(@"SELECT YearRel FROM Songs WHERE SongName = '{0}';", songname);

            cmd = new SqlCommand();
            cmd.Connection = db;
            cmd.CommandText = sql;

            result = cmd.ExecuteScalar();

            try
            {
                relDate = result.ToString();
                if (relDate.Length == 0)
                    relDate = "Unknown";
            }
            catch (Exception relDateException)
            {
                Console.WriteLine("{0} Exception Caught", relDateException);
                relDate = "Unknown";
            }

            //
            //get price from database
            //
            //cast price to decimal with 2 places
            sql = String.Format(@"SELECT CAST(Price AS DECIMAL(18,2)) FROM Songs WHERE SongName = '{0}';", songname);

            cmd = new SqlCommand();
            cmd.Connection = db;
            cmd.CommandText = sql;

            result = cmd.ExecuteScalar();

            try
            {
                price = System.Convert.ToDecimal(result);
            }
            catch (Exception priceException)
            {
                Console.WriteLine("{0} Exception Caught", priceException);
                price = -1;
            }

            //
            //get total number of reviews from database
            //
            int totalRev;
            //cast price to decimal with 2 places
            sql = String.Format(@"
                SELECT COUNT(ReviewID) FROM Reviews
                    INNER JOIN (
                    SELECT SongID FROM Songs WHERE SongName = '{0}'
                    ) T
                    ON Reviews.ReviewItemID = T.SongID
                    WHERE ReviewItemTypeID = 1;", songname);

            cmd = new SqlCommand();
            cmd.Connection = db;
            cmd.CommandText = sql;

            result = cmd.ExecuteScalar();

            try
            {
                totalRev = System.Convert.ToInt32(result);
                if (totalRev < 0)
                    totalRev = 0;
            }
            catch (Exception totalRevException)
            {
                Console.WriteLine("{0} Exception Caught", totalRevException);
                totalRev = 0;
            }

            //get ave rating from database
            //
            string aveRev;
            //cast price to decimal with 2 places
            sql = String.Format(@"
                    SELECT SUM(Rating)/CAST(COUNT(Rating) as DECIMAL(9,2)) FROM Reviews
                    INNER JOIN (
                    SELECT SongID FROM Songs WHERE SongName = '{0}'
                    ) T
                    ON Reviews.ReviewItemID = T.SongID
                    WHERE ReviewItemTypeID = 1;", songname);

            cmd = new SqlCommand();
            cmd.Connection = db;
            cmd.CommandText = sql;

            result = cmd.ExecuteScalar();

            try
            {
                aveRev = System.Convert.ToDecimal(result).ToString("0.0");
                if (System.Convert.ToDecimal(aveRev) < 0)
                    aveRev = "N/A";
            }
            catch (Exception aveRevException)
            {
                Console.WriteLine(aveRevException);
                aveRev = "N/A";
            }

            //activate labels to display artist info
            setDataLabels(artistname, relDate, price, totalRev, aveRev);

            db.Close();
        }

        private void albums_listbox_SelectedIndexChanged(object sender, EventArgs e)
        {
            //clear songs selection while albums list box is selected
            songs_listbox.SelectedIndex = -1;

            //hide purchase_labe - this label warns the user if they have bought an item previous or their
            //balance is too low
            purchase_label.Visible = false;

            //show purchase info labels and purchase button
            if (albums_listbox.SelectedIndex >= 0)
            {
                toggleLabels(true);
                purchase_button.Visible = true;
            }
            else
            {
                toggleLabels(false);
                purchase_button.Visible = false;
            }

            //initialize and open database
            string sql;
            //string firstname, lastname, password;
            SqlCommand cmd;
            object result;
            SqlConnection db = new SqlConnection(connectionInfo);
            db.Open();

            //
            //get artist name from database
            //
            string artistname;
            string albumname = albums_listbox.Text;
            sql = String.Format(@"
                SELECT ArtistName FROM Artists
	                INNER JOIN(
	                SELECT ArtistID FROM AlbumDetails
		                INNER JOIN(
		                SELECT AlbumID FROM Albums WHERE AlbumName = 'The wall'
		                ) T
		                ON AlbumDetails.AlbumID = T.AlbumID
	                ) T2
	                ON Artists.ArtistID = T2.ArtistID;", albumname);

            cmd = new SqlCommand();
            cmd.Connection = db;
            cmd.CommandText = sql;

            result = cmd.ExecuteScalar();
            try
            {
                artistname = result.ToString();
            }
            catch (Exception artistException)
            {
                Console.WriteLine("{0} Exception Caught", artistException);
                artistname = "Unknown";
            }

            //
            //get album id, this is to be used if the user tries to purchase this album
            //
            int albumid;
            sql = String.Format(@"
                SELECT AlbumID FROM Albums WHERE AlbumName = '{0}';", albumname);

            cmd = new SqlCommand();
            cmd.Connection = db;
            cmd.CommandText = sql;

            result = cmd.ExecuteScalar();
            try
            {
                albumid = System.Convert.ToInt32(result);
                purchaseItemid = albumid; //set purchaseitemid if user decides to buy
            }
            catch (Exception AlbumID)
            {
                Console.WriteLine("{0} Exception Caught", AlbumID);
                return; //error has occured
            }

            //
            //get release date from database
            //
            string relDate;
            sql = String.Format(@"SELECT YearRel FROM Albums WHERE AlbumName = '{0}';", albumname);

            cmd = new SqlCommand();
            cmd.Connection = db;
            cmd.CommandText = sql;

            result = cmd.ExecuteScalar();

            try
            {
                relDate = result.ToString();
                if (relDate.Length == 0)
                    relDate = "Unknown";
            }
            catch (Exception relDateException)
            {
                Console.WriteLine("{0} Exception Caught", relDateException);
                relDate = "Unknown";
            }

            //
            //get price from database
            //
            //cast price to decimal with 2 places
            sql = String.Format(@"SELECT CAST(Price AS DECIMAL(18,2)) FROM Albums WHERE Albumname = '{0}';", albumname);

            cmd = new SqlCommand();
            cmd.Connection = db;
            cmd.CommandText = sql;

            result = cmd.ExecuteScalar();
            try
            {
                price = System.Convert.ToDecimal(result);
            }
            catch (Exception priceException)
            {
                Console.WriteLine("{0} Exception Caught", priceException);
                price = -1;
            }

            //
            //get total number of reviews from database
            //
            int totalRev;
            //cast price to decimal with 2 places
            sql = String.Format(@"
                SELECT COUNT(ReviewID) FROM Reviews
                    INNER JOIN (
                    SELECT AlbumID FROM Albums WHERE Albumname = '{0}'
                    ) T
                    ON Reviews.ReviewItemID = T.AlbumID
                    WHERE ReviewItemTypeID = 2;", albumname);

            cmd = new SqlCommand();
            cmd.Connection = db;
            cmd.CommandText = sql;

            result = cmd.ExecuteScalar();
            try
            {
                totalRev = System.Convert.ToInt32(result);
                if (totalRev < 0)
                    totalRev = 0;
            }
            catch (Exception totalRevException)
            {
                Console.WriteLine("{0} Exception Caught", totalRevException);
                totalRev = 0;
            }

            //
            //get average rating from database
            //
            string aveRev;
            //cast price to decimal with 2 places
            sql = String.Format(@"
                SELECT SUM(Rating)/CAST(COUNT(Rating) as DECIMAL(9,2)) AS ave FROM Reviews
                    INNER JOIN (
                    SELECT AlbumID FROM Albums WHERE AlbumName = '{0}'
                    ) T
                    ON Reviews.ReviewItemID = T.AlbumID
                    WHERE ReviewItemTypeID = 2;", albumname);

            cmd = new SqlCommand();
            cmd.Connection = db;
            cmd.CommandText = sql;

            result = cmd.ExecuteScalar();
            try
            {
                aveRev = System.Convert.ToDecimal(result).ToString("0.0");
                if (System.Convert.ToDecimal(aveRev) < 0)
                    aveRev = "N/A";
            }
            catch (Exception aveRevException)
            {
                Console.WriteLine(aveRevException);
                aveRev = "N/A";
            }

            //
            //check if the song has already been purchased
            //
            sql = String.Format(@"
                SELECT UserID From Purchases
                    INNER JOIN(
                    SELECT PurchaseID FROM PurchaseDetails 
	                    INNER JOIN (
	                    SELECT AlbumID FROM Albums WHERE AlbumName = '{0}'
	                    ) T
	                    ON PurchaseDetails.PurchaseItemID = T.AlbumID
	                    WHERE PurchaseItemTypeID = 1
                    ) T2
                    ON Purchases.PurchaseID = T2.PurchaseID", albumname);

            cmd = new SqlCommand();
            cmd.Connection = db;
            cmd.CommandText = sql;

            result = cmd.ExecuteScalar();

            db.Close();

            //activate labels to display artist info
            setDataLabels(artistname, relDate, price, totalRev, aveRev);

        }

        private void toggleLabels(bool state)
        {
            //toggle text labels
            artist_text_label.Visible = state;
            release_date__text_label.Visible = state;
            price_text_label.Visible = state;
            total_reviews_text_label.Visible = state;
            average_review_text_label.Visible = state;

            //toggle data labels
            artist_data_label.Visible = state;
            release_date_data_label.Visible = state;
            price_data_label.Visible = state;
            total_reviews_data_label.Visible = state;
            average_review_data_label.Visible = state;
        }

        private void setDataLabels(string artistname, string relDate, decimal price, int totalRev, string aveRev)
        {
            artist_data_label.Text = artistname;
            release_date_data_label.Text = relDate;
            price_data_label.Text = price.ToString("0.00");
            total_reviews_data_label.Text = totalRev.ToString();
            average_review_data_label.Text = aveRev;
        }

        private void purchase_button_Click(object sender, EventArgs e)
        {
            //initialize and open database
            string sql;
            SqlCommand cmd;
            object result;
            SqlConnection db = new SqlConnection(connectionInfo);

            db.Open();

            int itemtypeid = -1;

            //determine which type of purchase is being made
            if (songs_listbox.SelectedIndex >= 0)
                itemtypeid = 1; //1 = song has been selected
            else if (albums_listbox.SelectedIndex >= 0)
                itemtypeid = 2; //2 = album has been selected
            else
            {
                MessageBox.Show("An error has occured. The itemtypeid could not be found.");
                return;
            }

            //check if user has already purchased the item selected
            if (itemtypeid == 1)
            {
                //check if song has already been purchased previously by this user
                sql = String.Format(@"
                SELECT UserID From Purchases
                    INNER JOIN(
                    SELECT PurchaseID FROM PurchaseDetails 
	                    INNER JOIN (
	                    SELECT SongID FROM Songs WHERE SongName = '{0}'
	                    ) T
	                    ON PurchaseDetails.PurchaseItemID = T.SongID
	                    WHERE PurchaseItemTypeID = 1
                    ) T2
                    ON Purchases.PurchaseID = T2.PurchaseID
                    WHERE USERID = {1};", songs_listbox.SelectedItem.ToString(), userid);

                cmd = new SqlCommand();
                cmd.Connection = db;
                cmd.CommandText = sql;

                int useridvalidate;

                result = cmd.ExecuteScalar();
                if (result == null)
                    useridvalidate = 0;
                else
                {
                    useridvalidate = System.Convert.ToInt32(result);
                }
                //if result is 1 and userid has purchased this song
                if (useridvalidate == userid)
                {
                    purchase_label.Text = "You've already purchased this song.";
                    purchase_label.ForeColor = System.Drawing.Color.Red;
                    purchase_label.Visible = true;
                    return;
                }
                else
                {
                    //user has not purchased this item because a userid doesn't exist!
                }
            }
            else
            {
                //check if album has already been purchased previously by this user
                sql = String.Format(@"
                SELECT UserID From Purchases
                    INNER JOIN(
                    SELECT PurchaseID FROM PurchaseDetails 
	                    INNER JOIN (
	                    SELECT AlbumID FROM Albums WHERE AlbumName = '{0}'
	                    ) T
	                    ON PurchaseDetails.PurchaseItemID = T.AlbumID
	                    WHERE PurchaseItemTypeID = 2
                    ) T2
                    ON Purchases.PurchaseID = T2.PurchaseID
                    WHERE USERID = {1};", albums_listbox.SelectedItem.ToString(), userid);

                cmd = new SqlCommand();
                cmd.Connection = db;
                cmd.CommandText = sql;

                int useridvalidate;

                result = cmd.ExecuteScalar();
                if (result == null)
                    useridvalidate = 0;
                else
                {
                    useridvalidate = System.Convert.ToInt32(result);
                }
                //if result is 1 and userid has purchased this albums
                if (useridvalidate == userid)
                {
                    purchase_label.Text = "You've already purchased this album.";
                    purchase_label.ForeColor = System.Drawing.Color.Red;
                    purchase_label.Visible = true;
                    return;
                }
                else
                {
                    //user has not purchased this item because a userid doesn't exist!
                }
            }

            //obtain old account balance
            sql = String.Format(@"SELECT AcctBal FROM Users WHERE UserID = {0};", userid);
            
            cmd = new SqlCommand();
            cmd.Connection = db;
            cmd.CommandText = sql;

            result = cmd.ExecuteScalar();
            accountBal = System.Convert.ToDecimal(result);

            //after obtaining account balance, check that the balance is above 0.
            if (accountBal <= 0)
            {
                purchase_label.Text = "Your account balance is too low to purchase this item.";
                purchase_label.ForeColor = System.Drawing.Color.Red;
                purchase_label.Visible = true;
            }
            //check that accountBal is enough to purchase item
            else if (accountBal < price)
            {
                //display account balance too low to purchase this item
                purchase_label.Text = "Your account balance is too low to purchase this item.";
                purchase_label.ForeColor = System.Drawing.Color.Red;
                purchase_label.Visible = true;
            }
            //purchase the item
            //this process takes the following steps:
                //update users account balance
                //update purchase table and get purchase id
                //update purcahse details table
            else
            {
                accountBal = accountBal - price;

                //update user's account bal in db
                sql = String.Format(@"UPDATE Users
                                    SET AcctBal = {0}
                                    WHERE UserID = '{1}';", accountBal, userid);

                cmd = new SqlCommand();
                cmd.Connection = db;
                cmd.CommandText = sql;
                cmd.ExecuteNonQuery();

                //update purchase table
                //get purchaseid
                sql = String.Format(@"INSERT INTO Purchases
                                    OUTPUT INSERTED.PurchaseID
                                    VALUES({0}, {1}, '{2}');", userid, price, DateTime.Now.ToString("yyyyMMdd"));

                cmd = new SqlCommand();
                cmd.Connection = db;
                cmd.CommandText = sql;
                
                result = cmd.ExecuteScalar();
                int purchaseid = System.Convert.ToInt32(result);

                //update purchase details table
                sql = String.Format(@"INSERT INTO PurchaseDetails
                                    VALUES({0}, {1}, {2});", purchaseid, itemtypeid, purchaseItemid);

                cmd = new SqlCommand();
                cmd.Connection = db;
                cmd.CommandText = sql;

                result = cmd.ExecuteNonQuery();

                //update account balance label
                accnt_bal_label.Text = accountBal.ToString("0.00");
            }

            //update account balance button and label
            if (accountBal <= 0)
            {
                accnt_bal_label.ForeColor = System.Drawing.Color.Red;
                //this.Visible = false; this line causes program to hide
            }
            else
            {
                accnt_bal_label.ForeColor = System.Drawing.Color.Green;
            }

            songs_listbox.SelectedItem = false; //deselect songs listbox
            albums_listbox.SelectedItem = false; //deselect albums listbox

            db.Close();
        }
    }
}