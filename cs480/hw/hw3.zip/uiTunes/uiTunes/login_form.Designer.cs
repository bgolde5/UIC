﻿namespace uiTunes
{
    partial class login_form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.password_textBox = new System.Windows.Forms.TextBox();
            this.lastname_textBox = new System.Windows.Forms.TextBox();
            this.password_label = new System.Windows.Forms.Label();
            this.lastname_label = new System.Windows.Forms.Label();
            this.firstname_label = new System.Windows.Forms.Label();
            this.firstname_textBox = new System.Windows.Forms.TextBox();
            this.login_button = new System.Windows.Forms.Button();
            this.invalid_input_label = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // password_textBox
            // 
            this.password_textBox.AcceptsTab = true;
            this.password_textBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 26F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.password_textBox.Location = new System.Drawing.Point(405, 246);
            this.password_textBox.Name = "password_textBox";
            this.password_textBox.Size = new System.Drawing.Size(374, 66);
            this.password_textBox.TabIndex = 13;
            this.password_textBox.UseSystemPasswordChar = true;
            // 
            // lastname_textBox
            // 
            this.lastname_textBox.AcceptsTab = true;
            this.lastname_textBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 26F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lastname_textBox.Location = new System.Drawing.Point(405, 164);
            this.lastname_textBox.Name = "lastname_textBox";
            this.lastname_textBox.Size = new System.Drawing.Size(374, 66);
            this.lastname_textBox.TabIndex = 12;
            // 
            // password_label
            // 
            this.password_label.AutoSize = true;
            this.password_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.password_label.Location = new System.Drawing.Point(111, 246);
            this.password_label.Name = "password_label";
            this.password_label.Size = new System.Drawing.Size(236, 55);
            this.password_label.TabIndex = 11;
            this.password_label.Text = "Password";
            // 
            // lastname_label
            // 
            this.lastname_label.AutoSize = true;
            this.lastname_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lastname_label.Location = new System.Drawing.Point(90, 164);
            this.lastname_label.Name = "lastname_label";
            this.lastname_label.Size = new System.Drawing.Size(257, 55);
            this.lastname_label.TabIndex = 10;
            this.lastname_label.Text = "Last Name";
            // 
            // firstname_label
            // 
            this.firstname_label.AutoSize = true;
            this.firstname_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.firstname_label.Location = new System.Drawing.Point(89, 82);
            this.firstname_label.Name = "firstname_label";
            this.firstname_label.Size = new System.Drawing.Size(258, 55);
            this.firstname_label.TabIndex = 9;
            this.firstname_label.Text = "First Name";
            // 
            // firstname_textBox
            // 
            this.firstname_textBox.AcceptsTab = true;
            this.firstname_textBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 26F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.firstname_textBox.Location = new System.Drawing.Point(405, 82);
            this.firstname_textBox.Name = "firstname_textBox";
            this.firstname_textBox.Size = new System.Drawing.Size(374, 66);
            this.firstname_textBox.TabIndex = 8;
            // 
            // login_button
            // 
            this.login_button.Font = new System.Drawing.Font("Webdings", 52F);
            this.login_button.Location = new System.Drawing.Point(317, 341);
            this.login_button.Name = "login_button";
            this.login_button.Size = new System.Drawing.Size(235, 110);
            this.login_button.TabIndex = 7;
            this.login_button.Text = "²";
            this.login_button.UseVisualStyleBackColor = true;
            this.login_button.Click += new System.EventHandler(this.login_button_Click);
            // 
            // invalid_input_label
            // 
            this.invalid_input_label.AutoSize = true;
            this.invalid_input_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.invalid_input_label.ForeColor = System.Drawing.Color.Red;
            this.invalid_input_label.Location = new System.Drawing.Point(228, 472);
            this.invalid_input_label.Name = "invalid_input_label";
            this.invalid_input_label.Size = new System.Drawing.Size(404, 25);
            this.invalid_input_label.TabIndex = 14;
            this.invalid_input_label.Text = "Invalid input, please re-enter your information.";
            this.invalid_input_label.Visible = false;
            // 
            // login_form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(868, 499);
            this.Controls.Add(this.invalid_input_label);
            this.Controls.Add(this.password_textBox);
            this.Controls.Add(this.lastname_textBox);
            this.Controls.Add(this.password_label);
            this.Controls.Add(this.lastname_label);
            this.Controls.Add(this.firstname_label);
            this.Controls.Add(this.firstname_textBox);
            this.Controls.Add(this.login_button);
            this.Name = "login_form";
            this.Text = "uiTunes Login";
            this.Load += new System.EventHandler(this.login_form_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox password_textBox;
        private System.Windows.Forms.TextBox lastname_textBox;
        private System.Windows.Forms.Label password_label;
        private System.Windows.Forms.Label lastname_label;
        private System.Windows.Forms.Label firstname_label;
        private System.Windows.Forms.TextBox firstname_textBox;
        private System.Windows.Forms.Button login_button;
        private System.Windows.Forms.Label invalid_input_label;
    }
}

