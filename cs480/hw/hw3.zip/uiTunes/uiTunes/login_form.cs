﻿//
// uiTunes music purchase application
//
// Braldey Golden
// U. of Illinois, Chicago
// CS480, Summer2015
// Homework 3
//

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace uiTunes
{
    public partial class login_form : Form
    {
        public static string firstname, lastname, password;
        public static int userid;
        public static string filename, connectionInfo;

        public login_form()
        {
            InitializeComponent();

            //constructor for uiTunes Database
            filename = "uiTunes.mdf";
            connectionInfo = String.Format(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=|DataDirectory|\{0};Integrated Security=True;", filename);
        }

        private void login_button_Click(object sender, EventArgs e)
        {
            string sql;
            //string firstname, lastname, password;
            userid = 0;
            SqlCommand cmd;
            object result;
            SqlConnection db = new SqlConnection(connectionInfo);
            db.Open();

            //check that the database connects properly
            //MessageBox.Show(db.State.ToString());

            //continue looping until user enters correct credentials
            //user with a value of 0 indicates the database could not find the entered credentials
            //get user's firstname, lastname, password from textbox's
            firstname = firstname_textBox.Text;
            lastname = lastname_textBox.Text;
            password = password_textBox.Text;

            //check that users credentials have been entered properly
            sql = String.Format(@"SELECT userID FROM Users WHERE FirstName = '{0}' AND LastName = '{1}' AND Pwd = '{2}';", firstname, lastname, password);
            //check sql query for user name
            //MessageBox.Show(sql);

            cmd = new SqlCommand();
            cmd.Connection = db;
            cmd.CommandText = sql;

            result = cmd.ExecuteScalar();

            //conver userid to int
            userid = System.Convert.ToInt32(result);

            //check that userid is obtained properly
            //MessageBox.Show(userid.ToString());

            if (userid == 0)
            {
                invalid_input_label.Visible = true;
                firstname_textBox.Clear();
                lastname_textBox.Clear();
                password_textBox.Clear();
            }

            else
            {
                invalid_input_label.Visible = false;
               
                //create new instance of purchase window
                purchase_form purchaseWindow = new purchase_form();

                //close database
                db.Close();

                //open the purhcase_form window and close database
                purchaseWindow.Show();
                this.Hide(); //hide the current login screen
            }  
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void login_form_Load(object sender, EventArgs e)
        {

        }
    }
}
