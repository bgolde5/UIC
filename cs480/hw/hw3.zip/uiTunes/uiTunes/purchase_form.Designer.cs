﻿namespace uiTunes
{
    partial class purchase_form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.uiTunesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.logoutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.username_label = new System.Windows.Forms.Label();
            this.accnt_bal_label = new System.Windows.Forms.Label();
            this.accnt_bal_text_label = new System.Windows.Forms.Label();
            this.songs_listbox = new System.Windows.Forms.ListBox();
            this.albums_listbox = new System.Windows.Forms.ListBox();
            this.songs_label = new System.Windows.Forms.Label();
            this.albums_label = new System.Windows.Forms.Label();
            this.artist_text_label = new System.Windows.Forms.Label();
            this.release_date__text_label = new System.Windows.Forms.Label();
            this.price_text_label = new System.Windows.Forms.Label();
            this.total_reviews_text_label = new System.Windows.Forms.Label();
            this.average_review_text_label = new System.Windows.Forms.Label();
            this.artist_data_label = new System.Windows.Forms.Label();
            this.release_date_data_label = new System.Windows.Forms.Label();
            this.price_data_label = new System.Windows.Forms.Label();
            this.total_reviews_data_label = new System.Windows.Forms.Label();
            this.average_review_data_label = new System.Windows.Forms.Label();
            this.purchase_button = new System.Windows.Forms.Button();
            this.purchase_label = new System.Windows.Forms.Label();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.uiTunesToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1202, 50);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // uiTunesToolStripMenuItem
            // 
            this.uiTunesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.logoutToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.uiTunesToolStripMenuItem.Font = new System.Drawing.Font("Webdings", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(2)));
            this.uiTunesToolStripMenuItem.Name = "uiTunesToolStripMenuItem";
            this.uiTunesToolStripMenuItem.Size = new System.Drawing.Size(70, 46);
            this.uiTunesToolStripMenuItem.Text = "²";
            this.uiTunesToolStripMenuItem.Click += new System.EventHandler(this.uiTunesToolStripMenuItem_Click);
            // 
            // logoutToolStripMenuItem
            // 
            this.logoutToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.logoutToolStripMenuItem.Name = "logoutToolStripMenuItem";
            this.logoutToolStripMenuItem.Size = new System.Drawing.Size(147, 30);
            this.logoutToolStripMenuItem.Text = "Logout";
            this.logoutToolStripMenuItem.Click += new System.EventHandler(this.logoutToolStripMenuItem_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(147, 30);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // username_label
            // 
            this.username_label.AutoSize = true;
            this.username_label.BackColor = System.Drawing.Color.Transparent;
            this.username_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.username_label.Location = new System.Drawing.Point(513, 12);
            this.username_label.Name = "username_label";
            this.username_label.Size = new System.Drawing.Size(46, 25);
            this.username_label.TabIndex = 1;
            this.username_label.Text = "null";
            this.username_label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.username_label.Click += new System.EventHandler(this.label1_Click);
            // 
            // accnt_bal_label
            // 
            this.accnt_bal_label.AutoSize = true;
            this.accnt_bal_label.BackColor = System.Drawing.Color.Transparent;
            this.accnt_bal_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.accnt_bal_label.Location = new System.Drawing.Point(1121, 13);
            this.accnt_bal_label.Name = "accnt_bal_label";
            this.accnt_bal_label.Size = new System.Drawing.Size(42, 22);
            this.accnt_bal_label.TabIndex = 2;
            this.accnt_bal_label.Text = "null";
            this.accnt_bal_label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // accnt_bal_text_label
            // 
            this.accnt_bal_text_label.AutoSize = true;
            this.accnt_bal_text_label.BackColor = System.Drawing.Color.Transparent;
            this.accnt_bal_text_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.accnt_bal_text_label.Location = new System.Drawing.Point(851, 12);
            this.accnt_bal_text_label.Name = "accnt_bal_text_label";
            this.accnt_bal_text_label.Size = new System.Drawing.Size(182, 25);
            this.accnt_bal_text_label.TabIndex = 3;
            this.accnt_bal_text_label.Text = "Account Balance:";
            this.accnt_bal_text_label.Click += new System.EventHandler(this.label1_Click_1);
            // 
            // songs_listbox
            // 
            this.songs_listbox.FormattingEnabled = true;
            this.songs_listbox.ItemHeight = 20;
            this.songs_listbox.Location = new System.Drawing.Point(10, 87);
            this.songs_listbox.Name = "songs_listbox";
            this.songs_listbox.Size = new System.Drawing.Size(469, 444);
            this.songs_listbox.TabIndex = 4;
            this.songs_listbox.SelectedIndexChanged += new System.EventHandler(this.songs_listbox_SelectedIndexChanged);
            // 
            // albums_listbox
            // 
            this.albums_listbox.FormattingEnabled = true;
            this.albums_listbox.ItemHeight = 20;
            this.albums_listbox.Location = new System.Drawing.Point(715, 89);
            this.albums_listbox.Name = "albums_listbox";
            this.albums_listbox.Size = new System.Drawing.Size(469, 444);
            this.albums_listbox.TabIndex = 5;
            this.albums_listbox.SelectedIndexChanged += new System.EventHandler(this.albums_listbox_SelectedIndexChanged);
            // 
            // songs_label
            // 
            this.songs_label.AutoSize = true;
            this.songs_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.songs_label.Location = new System.Drawing.Point(210, 59);
            this.songs_label.Name = "songs_label";
            this.songs_label.Size = new System.Drawing.Size(69, 25);
            this.songs_label.TabIndex = 6;
            this.songs_label.Text = "Songs";
            this.songs_label.Click += new System.EventHandler(this.songs_label_Click);
            // 
            // albums_label
            // 
            this.albums_label.AutoSize = true;
            this.albums_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.albums_label.Location = new System.Drawing.Point(910, 59);
            this.albums_label.Name = "albums_label";
            this.albums_label.Size = new System.Drawing.Size(78, 25);
            this.albums_label.TabIndex = 7;
            this.albums_label.Text = "Albums";
            this.albums_label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // artist_text_label
            // 
            this.artist_text_label.AutoSize = true;
            this.artist_text_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.artist_text_label.Location = new System.Drawing.Point(210, 601);
            this.artist_text_label.Name = "artist_text_label";
            this.artist_text_label.Size = new System.Drawing.Size(62, 25);
            this.artist_text_label.TabIndex = 8;
            this.artist_text_label.Text = "Artist:";
            this.artist_text_label.Visible = false;
            // 
            // release_date__text_label
            // 
            this.release_date__text_label.AutoSize = true;
            this.release_date__text_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.release_date__text_label.Location = new System.Drawing.Point(137, 641);
            this.release_date__text_label.Name = "release_date__text_label";
            this.release_date__text_label.Size = new System.Drawing.Size(135, 25);
            this.release_date__text_label.TabIndex = 9;
            this.release_date__text_label.Text = "Release Date:";
            this.release_date__text_label.Visible = false;
            // 
            // price_text_label
            // 
            this.price_text_label.AutoSize = true;
            this.price_text_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.price_text_label.Location = new System.Drawing.Point(210, 681);
            this.price_text_label.Name = "price_text_label";
            this.price_text_label.Size = new System.Drawing.Size(62, 25);
            this.price_text_label.TabIndex = 10;
            this.price_text_label.Text = "Price:";
            this.price_text_label.Visible = false;
            // 
            // total_reviews_text_label
            // 
            this.total_reviews_text_label.AutoSize = true;
            this.total_reviews_text_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.total_reviews_text_label.Location = new System.Drawing.Point(37, 721);
            this.total_reviews_text_label.Name = "total_reviews_text_label";
            this.total_reviews_text_label.Size = new System.Drawing.Size(235, 25);
            this.total_reviews_text_label.TabIndex = 11;
            this.total_reviews_text_label.Text = "Total Number of Reviews:";
            this.total_reviews_text_label.Visible = false;
            // 
            // average_review_text_label
            // 
            this.average_review_text_label.AutoSize = true;
            this.average_review_text_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.average_review_text_label.Location = new System.Drawing.Point(112, 761);
            this.average_review_text_label.Name = "average_review_text_label";
            this.average_review_text_label.Size = new System.Drawing.Size(160, 25);
            this.average_review_text_label.TabIndex = 12;
            this.average_review_text_label.Text = "Average Review:";
            this.average_review_text_label.Visible = false;
            // 
            // artist_data_label
            // 
            this.artist_data_label.AutoSize = true;
            this.artist_data_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.artist_data_label.Location = new System.Drawing.Point(342, 601);
            this.artist_data_label.Name = "artist_data_label";
            this.artist_data_label.Size = new System.Drawing.Size(42, 25);
            this.artist_data_label.TabIndex = 13;
            this.artist_data_label.Text = "null";
            this.artist_data_label.Visible = false;
            // 
            // release_date_data_label
            // 
            this.release_date_data_label.AutoSize = true;
            this.release_date_data_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.release_date_data_label.Location = new System.Drawing.Point(342, 641);
            this.release_date_data_label.Name = "release_date_data_label";
            this.release_date_data_label.Size = new System.Drawing.Size(42, 25);
            this.release_date_data_label.TabIndex = 14;
            this.release_date_data_label.Text = "null";
            this.release_date_data_label.Visible = false;
            // 
            // price_data_label
            // 
            this.price_data_label.AutoSize = true;
            this.price_data_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.price_data_label.Location = new System.Drawing.Point(342, 681);
            this.price_data_label.Name = "price_data_label";
            this.price_data_label.Size = new System.Drawing.Size(42, 25);
            this.price_data_label.TabIndex = 15;
            this.price_data_label.Text = "null";
            this.price_data_label.Visible = false;
            // 
            // total_reviews_data_label
            // 
            this.total_reviews_data_label.AutoSize = true;
            this.total_reviews_data_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.total_reviews_data_label.Location = new System.Drawing.Point(342, 721);
            this.total_reviews_data_label.Name = "total_reviews_data_label";
            this.total_reviews_data_label.Size = new System.Drawing.Size(42, 25);
            this.total_reviews_data_label.TabIndex = 16;
            this.total_reviews_data_label.Text = "null";
            this.total_reviews_data_label.Visible = false;
            // 
            // average_review_data_label
            // 
            this.average_review_data_label.AutoSize = true;
            this.average_review_data_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.average_review_data_label.Location = new System.Drawing.Point(342, 761);
            this.average_review_data_label.Name = "average_review_data_label";
            this.average_review_data_label.Size = new System.Drawing.Size(42, 25);
            this.average_review_data_label.TabIndex = 17;
            this.average_review_data_label.Text = "null";
            this.average_review_data_label.Visible = false;
            // 
            // purchase_button
            // 
            this.purchase_button.Location = new System.Drawing.Point(818, 632);
            this.purchase_button.Name = "purchase_button";
            this.purchase_button.Size = new System.Drawing.Size(223, 103);
            this.purchase_button.TabIndex = 18;
            this.purchase_button.Text = "Purchase";
            this.purchase_button.UseVisualStyleBackColor = true;
            this.purchase_button.Visible = false;
            this.purchase_button.Click += new System.EventHandler(this.purchase_button_Click);
            // 
            // purchase_label
            // 
            this.purchase_label.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.purchase_label.AutoSize = true;
            this.purchase_label.Location = new System.Drawing.Point(754, 761);
            this.purchase_label.Name = "purchase_label";
            this.purchase_label.Size = new System.Drawing.Size(33, 20);
            this.purchase_label.TabIndex = 19;
            this.purchase_label.Text = "null";
            this.purchase_label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.purchase_label.Visible = false;
            // 
            // purchase_form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(1202, 850);
            this.Controls.Add(this.purchase_label);
            this.Controls.Add(this.purchase_button);
            this.Controls.Add(this.average_review_data_label);
            this.Controls.Add(this.total_reviews_data_label);
            this.Controls.Add(this.price_data_label);
            this.Controls.Add(this.release_date_data_label);
            this.Controls.Add(this.artist_data_label);
            this.Controls.Add(this.average_review_text_label);
            this.Controls.Add(this.total_reviews_text_label);
            this.Controls.Add(this.price_text_label);
            this.Controls.Add(this.release_date__text_label);
            this.Controls.Add(this.artist_text_label);
            this.Controls.Add(this.albums_label);
            this.Controls.Add(this.songs_label);
            this.Controls.Add(this.albums_listbox);
            this.Controls.Add(this.songs_listbox);
            this.Controls.Add(this.accnt_bal_text_label);
            this.Controls.Add(this.accnt_bal_label);
            this.Controls.Add(this.username_label);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "purchase_form";
            this.Text = "uiTunes";
            this.Load += new System.EventHandler(this.purchase_form_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem uiTunesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem logoutToolStripMenuItem;
        private System.Windows.Forms.Label username_label;
        private System.Windows.Forms.Label accnt_bal_label;
        private System.Windows.Forms.Label accnt_bal_text_label;
        private System.Windows.Forms.ListBox songs_listbox;
        private System.Windows.Forms.ListBox albums_listbox;
        private System.Windows.Forms.Label songs_label;
        private System.Windows.Forms.Label albums_label;
        private System.Windows.Forms.Label artist_text_label;
        private System.Windows.Forms.Label release_date__text_label;
        private System.Windows.Forms.Label price_text_label;
        private System.Windows.Forms.Label total_reviews_text_label;
        private System.Windows.Forms.Label average_review_text_label;
        private System.Windows.Forms.Label artist_data_label;
        private System.Windows.Forms.Label release_date_data_label;
        private System.Windows.Forms.Label price_data_label;
        private System.Windows.Forms.Label total_reviews_data_label;
        private System.Windows.Forms.Label average_review_data_label;
        private System.Windows.Forms.Button purchase_button;
        private System.Windows.Forms.Label purchase_label;
    }
}