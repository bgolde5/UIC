1. Compile using “make fakemake”
2. Run using ./a.out <filename>
3. All standard input options apply (touch, make, etc.)
4. Clean using “make clean”

Note: Requires g++ 14