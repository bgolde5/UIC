1. Build using "make all"
2. Run using ./dp401 <pins-file>
2. Clean using "make clean"
3. Create a random dataset using "python generate.py <filename> <num values>"
